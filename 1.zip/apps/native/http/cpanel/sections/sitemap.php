<?php 


$cl["app_statics"] = array(
	"scripts" => array(
		cl_static_file_path("statics/js/libs/jquery-plugins/jquery.form-v4.2.2.min.js")
	)
);

$cl['http_res'] = cl_template("cpanel/assets/sitemap/content");
