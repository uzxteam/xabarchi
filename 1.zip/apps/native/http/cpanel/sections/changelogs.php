<?php 


$cl['http_res'] = cl_template("cpanel/assets/changelogs/content");